# Vibe Coding — Codex Global Core

A **user-level global** Codex installation package distilled from the OpenCode Vibe Coding framework.

## Included

- Global Vibe Coding main-agent/persona instructions injected into a managed block in `~/.codex/AGENTS.md`.
- 30 migrated Vibe Skills installed under `~/.codex/skills/`.
- Global runtime under `~/.codex/vibe-workflow/`: project-log template, initializer, status tool, and schema validators.
- Optional global Codex MCP plugin (`vibe-toolbelt`) with five task-oriented capabilities: Context7, GitHub, Playwright, document loader, and web search.

## Intentionally excluded

- OpenCode model providers, API keys, provider configuration, package-lock/node_modules, history, sessions, memory/cache, and TUI/title settings.
- OpenCode agent/command file formats and OpenCode TypeScript plugins. Their workflow behavior is distilled into the global main-agent prompt, Skills, project log, and Codex plugin.
- The OpenCode-only migration-packager Skill.

## Install globally

Linux/macOS:

```bash
chmod +x install.sh uninstall.sh
./install.sh
```

Windows PowerShell:

```powershell
.\install.ps1
```

For isolated testing or a nonstandard Codex home:

```bash
python3 scripts/global_installer.py install --codex-home /tmp/codex-home
```

The installer makes a timestamped backup under `<CODEX_HOME>/backups/` and only replaces its own
`<!-- VIBE-CODEX-GLOBAL:BEGIN -->` block. It does not delete other global instructions.

## Verify / uninstall

```bash
python3 scripts/global_installer.py verify
python3 scripts/global_installer.py uninstall
```

Uninstall removes only the Vibe managed block, Vibe runtime, Vibe Skills installed by this package,
and the optional `vibe-toolbelt` registration. It restores pre-existing same-named skills when a backup exists;
locally modified installed skills are preserved and reported.

## MCP prerequisites

MCP services are optional but installed as a global Codex plugin by default. Their commands/services are not bundled:

- Node.js + `npx`: GitHub, Playwright, web search
- `uvx`: document loader
- Playwright browser installation when browser automation is used
- Optional runtime `GITHUB_TOKEN`; no credentials are stored in this package

Use `--without-mcp` if you only want the global persona, Skills, and runtime.
