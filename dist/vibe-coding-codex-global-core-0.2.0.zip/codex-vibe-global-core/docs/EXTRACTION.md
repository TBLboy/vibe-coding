# Core extraction

The source framework had 31 Skills, OpenCode roles/commands, provider definitions, MCP entries, TypeScript plugins, and runtime state.

This global package preserves the core that affects day-to-day Vibe Coding behavior:

1. the Vibe Coding primary-agent persona and authority/lifecycle rules;
2. 30 task Skills, host-normalized from OpenCode to Codex;
3. persistent global workflow runtime and project-log initializer;
4. a small MCP toolbelt chosen by task coverage rather than exact OpenCode parity.

It deliberately avoids copying implementation-specific OpenCode providers, agent formats, commands, plugins, credentials, and historical state.
