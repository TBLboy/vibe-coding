#!/usr/bin/env python3
"""Validate Vibe Workflow data, Skill metadata, Agent metadata, and cross-references."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
    from jsonschema import Draft202012Validator
except ImportError as exc:  # pragma: no cover
    print(
        "Missing dependency. Run: python -m pip install -r scripts/requirements.txt",
        file=sys.stderr,
    )
    raise SystemExit(2) from exc


DATA_SCHEMAS = {
    ".project-log/workflow.yaml": ".project-log/schemas/workflow.schema.json",
    ".project-log/business-logic/atoms.yaml": ".project-log/schemas/business-logic.schema.json",
    ".project-log/business-logic/open-questions.yaml": ".project-log/schemas/open-questions.schema.json",
    ".project-log/tasks/task-list.yaml": ".project-log/schemas/task-list.schema.json",
    ".project-log/decisions/decision-log.yaml": ".project-log/schemas/decision-log.schema.json",
    ".project-log/requirements/baseline.yaml": ".project-log/schemas/requirement-baseline.schema.json",
    ".project-log/research/solution-research.yaml": ".project-log/schemas/solution-research.schema.json",
    ".project-log/architecture/architecture.yaml": ".project-log/schemas/architecture.schema.json",
    ".project-log/alignment/findings.yaml": ".project-log/schemas/alignment.schema.json",
    ".project-log/verification/evidence.yaml": ".project-log/schemas/verification-evidence.schema.json",
    ".project-log/work-trace/trace.yaml": ".project-log/schemas/work-trace.schema.json",
    ".project-log/retrospective/retrospective.yaml": ".project-log/schemas/retrospective.schema.json",
    ".project-log/distillation/candidates.yaml": ".project-log/schemas/distillation.schema.json",
}

SKILL_NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


def load_yaml(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def parse_frontmatter(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        raise ValueError("missing YAML frontmatter")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise ValueError("unterminated YAML frontmatter")
    data = yaml.safe_load(text[4:end])
    if not isinstance(data, dict):
        raise ValueError("frontmatter is not a mapping")
    return data


def schema_errors(root: Path) -> tuple[list[str], dict[str, Any]]:
    errors: list[str] = []
    loaded: dict[str, Any] = {}
    for data_rel, schema_rel in DATA_SCHEMAS.items():
        data_path = root / data_rel
        schema_path = root / schema_rel
        if not data_path.exists():
            errors.append(f"missing data file: {data_rel}")
            continue
        if not schema_path.exists():
            errors.append(f"missing schema file: {schema_rel}")
            continue
        try:
            data = load_yaml(data_path)
            schema = load_json(schema_path)
            loaded[data_rel] = data
            validator = Draft202012Validator(schema)
            for item in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
                location = ".".join(str(part) for part in item.path) or "<root>"
                errors.append(f"{data_rel}:{location}: {item.message}")
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{data_rel}: failed to load/validate: {exc}")
    return errors, loaded


def metadata_errors(root: Path) -> list[str]:
    errors: list[str] = []
    skills_root = root / ".opencode/skills"
    skill_names: set[str] = set()
    for path in sorted(skills_root.glob("*/SKILL.md")):
        try:
            meta = parse_frontmatter(path)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{path.relative_to(root)}: {exc}")
            continue
        expected = path.parent.name
        name = meta.get("name")
        if name != expected:
            errors.append(f"{path.relative_to(root)}: name {name!r} does not match directory {expected!r}")
        if not isinstance(name, str) or not SKILL_NAME_RE.fullmatch(name):
            errors.append(f"{path.relative_to(root)}: invalid skill name")
        elif name != expected:
            pass
        else:
            skill_names.add(name)
        description = meta.get("description")
        if not isinstance(description, str) or not (1 <= len(description) <= 1024):
            errors.append(f"{path.relative_to(root)}: description must be 1-1024 chars")
        allowed = {"name", "description", "license", "compatibility", "metadata"}
        unknown = sorted(set(meta) - allowed)
        if unknown:
            errors.append(f"{path.relative_to(root)}: unsupported frontmatter fields: {unknown}")

    commands_root = root / ".opencode/commands"
    for name in sorted(skill_names):
        command = commands_root / f"{name}.md"
        if not command.exists():
            errors.append(f"missing manual Skill command: .opencode/commands/{name}.md")

    router = root / ".opencode/agents/vibe-goal.md"
    if router.exists():
        referenced = set(re.findall(r"`((?:a|b)-[a-z0-9]+(?:-[a-z0-9]+)*)`", router.read_text(encoding="utf-8")))
        for name in sorted(referenced - skill_names):
            errors.append(f".opencode/agents/vibe-goal.md: routes unknown Skill {name!r}")

    for path in sorted((root / ".opencode/agents").glob("*.md")):
        try:
            meta = parse_frontmatter(path)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{path.relative_to(root)}: {exc}")
            continue
        if meta.get("mode") not in {"primary", "subagent"}:
            errors.append(f"{path.relative_to(root)}: mode must be primary or subagent")
        if not isinstance(meta.get("description"), str):
            errors.append(f"{path.relative_to(root)}: missing description")
    return errors


def unique_ids(items: list[dict[str, Any]], label: str, errors: list[str]) -> set[str]:
    seen: set[str] = set()
    for item in items:
        ident = item.get("id")
        if ident in seen:
            errors.append(f"duplicate {label} id: {ident}")
        if isinstance(ident, str):
            seen.add(ident)
    return seen


def cross_reference_errors(loaded: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    atoms = loaded.get(".project-log/business-logic/atoms.yaml", {}).get("atoms", [])
    tasks = loaded.get(".project-log/tasks/task-list.yaml", {}).get("tasks", [])
    decisions = loaded.get(".project-log/decisions/decision-log.yaml", {}).get("decisions", [])
    baselines = loaded.get(".project-log/requirements/baseline.yaml", {}).get("baselines", [])
    studies = loaded.get(".project-log/research/solution-research.yaml", {}).get("studies", [])
    architectures = loaded.get(".project-log/architecture/architecture.yaml", {}).get("architectures", [])
    findings = loaded.get(".project-log/alignment/findings.yaml", {}).get("findings", [])
    questions = loaded.get(".project-log/business-logic/open-questions.yaml", {}).get("questions", [])

    bl_ids = unique_ids(atoms, "business logic", errors)
    task_ids = unique_ids(tasks, "task", errors)
    dec_ids = unique_ids(decisions, "decision", errors)
    req_ids = unique_ids(baselines, "requirement baseline", errors)
    unique_ids(studies, "solution research", errors)
    unique_ids(architectures, "architecture", errors)
    unique_ids(findings, "alignment finding", errors)
    question_ids = unique_ids(questions, "open question", errors)

    def require_refs(owner: str, refs: list[str], valid: set[str], kind: str) -> None:
        for ref in refs:
            if ref not in valid:
                errors.append(f"{owner}: unknown {kind} reference {ref}")

    for atom in atoms:
        owner = atom["id"]
        require_refs(owner, atom.get("dependencies", []), bl_ids, "business logic")
        require_refs(owner, atom.get("decision_refs", []), dec_ids, "decision")
        require_refs(owner, atom.get("baseline_refs", []), req_ids, "baseline")

    for task in tasks:
        owner = task["id"]
        require_refs(owner, task.get("related_business_logic", []), bl_ids, "business logic")
        require_refs(owner, task.get("related_decisions", []), dec_ids, "decision")
        require_refs(owner, task.get("depends_on", []), task_ids, "task")
        require_refs(owner, task.get("blocked_by", []), task_ids, "task")
        require_refs(owner, task.get("blocked_by_questions", []), question_ids, "open question")
        parent = task.get("parent_id")
        if parent is not None and parent not in task_ids:
            errors.append(f"{owner}: unknown parent task {parent}")
        if owner in task.get("depends_on", []):
            errors.append(f"{owner}: task cannot depend on itself")
        if task.get("status") == "done":
            verification = task.get("verification", {})
            if verification.get("status") not in {"passed", "not-applicable"}:
                errors.append(f"{owner}: done task lacks passed/not-applicable verification")

    for question in questions:
        owner = question["id"]
        require_refs(owner, question.get("related_business_logic", []), bl_ids, "business logic")
        require_refs(owner, question.get("related_tasks", []), task_ids, "task")
        if question.get("authority") == "C" and question.get("status") == "answered" and not question.get("answer"):
            errors.append(f"{owner}: answered C-level question has no answer")

    for decision in decisions:
        owner = decision["id"]
        require_refs(owner, decision.get("related_tasks", []), task_ids, "task")
        require_refs(owner, decision.get("related_business_logic", []), bl_ids, "business logic")
        if decision.get("authority") == "C" and decision.get("user_approval") == "not-required":
            errors.append(f"{owner}: C-level decision cannot use user_approval=not-required")

    for baseline in baselines:
        require_refs(baseline["id"], baseline.get("business_logic_refs", []), bl_ids, "business logic")

    for study in studies:
        require_refs(study["id"], study.get("related_business_logic", []), bl_ids, "business logic")
        require_refs(study["id"], study.get("related_tasks", []), task_ids, "task")
        ref = study.get("decision_ref")
        if ref is not None and ref not in dec_ids:
            errors.append(f"{study['id']}: unknown decision reference {ref}")

    for arch in architectures:
        require_refs(arch["id"], arch.get("related_business_logic", []), bl_ids, "business logic")
        require_refs(arch["id"], arch.get("decision_refs", []), dec_ids, "decision")

    for finding in findings:
        require_refs(finding["id"], finding.get("business_logic_refs", []), bl_ids, "business logic")
        require_refs(finding["id"], finding.get("related_tasks", []), task_ids, "task")

    return errors


def validate(root: Path) -> list[str]:
    schema, loaded = schema_errors(root)
    return schema + metadata_errors(root) + cross_reference_errors(loaded)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Project root")
    args = parser.parse_args()
    root = args.root.expanduser().resolve()
    errors = validate(root)
    if errors:
        print(f"Validation failed with {len(errors)} issue(s):")
        for error in errors:
            print(f"- {error}")
        return 1
    print("Validation passed: schemas, metadata, and cross-references are consistent.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
