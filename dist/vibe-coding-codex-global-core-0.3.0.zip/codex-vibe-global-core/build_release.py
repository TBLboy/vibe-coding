#!/usr/bin/env python3
"""Validate and create a portable ZIP for the Vibe Coding global Codex package."""
from __future__ import annotations

import hashlib
from pathlib import Path
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

EXCLUDED_DIRS = {".git", "__pycache__", "dist"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".zip"}


def include(path: Path, root: Path) -> bool:
    rel = path.relative_to(root)
    return path.is_file() and not any(part in EXCLUDED_DIRS for part in rel.parts) and path.suffix not in EXCLUDED_SUFFIXES


def main() -> int:
    root = Path(__file__).resolve().parent
    validator = Path.home() / ".codex" / "skills" / ".system" / "plugin-creator" / "scripts" / "validate_plugin.py"
    plugin = root / "plugins" / "vibe-toolbelt"
    if validator.is_file() and subprocess.call([sys.executable, str(validator), str(plugin)]):
        return 1
    out = root / "dist"
    out.mkdir(exist_ok=True)
    archive = out / "vibe-coding-codex-global-core-0.3.0.zip"
    with ZipFile(archive, "w", compression=ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(root.rglob("*")):
            if not include(path, root):
                continue
            arcname = Path(root.name) / path.relative_to(root)
            info = ZipInfo.from_file(path, arcname=arcname.as_posix())
            info.date_time = (2026, 7, 23, 0, 0, 0)
            info.compress_type = ZIP_DEFLATED
            zf.writestr(info, path.read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    archive.with_suffix(archive.suffix + ".sha256").write_text(f"{digest}  {archive.name}\n", encoding="utf-8")
    print(f"Archive: {archive}")
    print(f"SHA-256: {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
