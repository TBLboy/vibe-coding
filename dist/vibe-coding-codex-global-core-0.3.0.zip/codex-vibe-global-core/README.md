# Vibe Coding — Codex Global Core

A **user-level global** Codex installation package distilled from the OpenCode Vibe Coding framework.

## Included

- Global Vibe Coding main-agent/persona instructions injected into a managed block in `~/.codex/AGENTS.md`.
- 31 migrated Vibe Skills, including dynamic subagent orchestration installed under `~/.codex/skills/`.
- Global runtime under `~/.codex/vibe-workflow/`: project-log template, initializer, status tool, schema validators, eight role templates, and a deterministic subagent-prompt renderer.
- Optional global Codex MCP plugin (`vibe-toolbelt`) with five task-oriented capabilities: Context7, GitHub, Playwright, document loader, and web search.

## Intentionally excluded

- OpenCode model providers, API keys, provider configuration, package-lock/node_modules, history, sessions, memory/cache, and TUI/title settings.
- OpenCode agent/command file formats and OpenCode TypeScript plugins. Their workflow behavior is distilled into the global main-agent prompt, Skills, project log, and Codex plugin.
- The OpenCode-only migration-packager Skill.

## Dynamic subagents

The global Vibe Goal main agent can dynamically delegate the eight migrated roles: business analyst, codebase onboarder, solution researcher, implementation builder, verification reviewer, alignment reviewer, paper reader, and workflow distiller. They are not permanent background processes: Codex receives a role template plus a bounded task, project root, scope, and write policy for each delegation. The main agent retains all C-level decisions and final integration.

Render a role prompt manually when needed:

```bash
VIBE_RUNTIME="${CODEX_HOME:-$HOME/.codex}/vibe-workflow"
python3 "$VIBE_RUNTIME/scripts/render_subagent_prompt.py" \
  --role verification-reviewer --project-root /path/to/project \
  --task "Verify TASK-014 acceptance criteria" --scope "Read-only; run existing tests"
```

## Install globally

Linux/macOS:

```bash
chmod +x install.sh uninstall.sh
./install.sh
```

Windows PowerShell:

```powershell
.\install.ps1
```

For isolated testing or a nonstandard Codex home:

```bash
python3 scripts/global_installer.py install --codex-home /tmp/codex-home
```

The installer makes a timestamped backup under `<CODEX_HOME>/backups/` and only replaces its own
`<!-- VIBE-CODEX-GLOBAL:BEGIN -->` block. It does not delete other global instructions.

## Verify / uninstall

```bash
python3 scripts/global_installer.py verify
python3 scripts/global_installer.py uninstall
```

Uninstall removes only the Vibe managed block, Vibe runtime, Vibe Skills installed by this package,
and the optional `vibe-toolbelt` registration. It restores pre-existing same-named skills when a backup exists;
locally modified installed skills are preserved and reported.

## MCP prerequisites

MCP services are optional but installed as a global Codex plugin by default. Their commands/services are not bundled:

- Node.js + `npx`: GitHub, Playwright, web search
- `uvx`: document loader
- Playwright browser installation when browser automation is used
- Optional runtime `GITHUB_TOKEN`; no credentials are stored in this package

Use `--without-mcp` if you only want the global persona, Skills, and runtime.
