#!/usr/bin/env python3
"""Install, verify, or remove the Vibe Coding global core from a Codex home."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

TITLE = "Vibe Coding — Codex Global Core"
BEGIN = "<!-- VIBE-CODEX-GLOBAL:BEGIN -->"
END = "<!-- VIBE-CODEX-GLOBAL:END -->"
PLUGIN = "vibe-toolbelt@vibe-global-toolbox"
PLUGIN_MARKETPLACE = "vibe-global-toolbox"
STATE_NAME = "installation-state.json"
EXCLUDED_TREE_NAMES = {"__pycache__", STATE_NAME}


def package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def code_home(value: str | None) -> Path:
    raw = value or os.environ.get("CODEX_HOME")
    return Path(raw).expanduser().resolve() if raw else (Path.home() / ".codex").resolve()


def norm(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n").strip()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tree_hash(path: Path) -> str:
    digest = hashlib.sha256()
    if not path.exists():
        return ""
    for item in sorted(path.rglob("*")):
        if not item.is_file() or any(part in EXCLUDED_TREE_NAMES for part in item.relative_to(path).parts):
            continue
        rel = item.relative_to(path).as_posix().encode("utf-8")
        digest.update(len(rel).to_bytes(4, "big"))
        digest.update(rel)
        digest.update(sha256_file(item).encode("ascii"))
    return digest.hexdigest()


def source_skills(root: Path) -> list[Path]:
    skills = sorted((root / "skills").iterdir())
    if not skills or any(not (skill / "SKILL.md").is_file() for skill in skills):
        raise RuntimeError("Package skills are incomplete.")
    return skills


def managed_pattern() -> re.Pattern[str]:
    return re.compile(re.escape(BEGIN) + r"[\s\S]*?" + re.escape(END), re.MULTILINE)


def stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")


def backup(home: Path, action: str, skills: list[Path]) -> Path:
    dest = home / "backups" / f"vibe-global-{action}-{stamp()}"
    dest.mkdir(parents=True, exist_ok=True)
    agents = home / "AGENTS.md"
    if agents.exists():
        shutil.copy2(agents, dest / "AGENTS.md")
    runtime = home / "vibe-workflow"
    if runtime.exists():
        shutil.copytree(runtime, dest / "vibe-workflow")
    for skill in skills:
        current = home / "skills" / skill.name
        if current.exists():
            shutil.copytree(current, dest / "skills" / skill.name)
    return dest


def plugin_env(home: Path) -> dict[str, str]:
    env = os.environ.copy()
    env["CODEX_HOME"] = str(home)
    return env


def run_plugin(home: Path, root: Path, remove: bool = False) -> bool:
    if shutil.which("codex") is None:
        print("[!] codex CLI was not found; skipped optional MCP plugin action.")
        return False
    env = plugin_env(home)
    if remove:
        subprocess.run(["codex", "plugin", "remove", PLUGIN], env=env, check=False)
        subprocess.run(["codex", "plugin", "marketplace", "remove", PLUGIN_MARKETPLACE], env=env, check=False)
        return True
    subprocess.run(["codex", "plugin", "marketplace", "add", str(root)], env=env, check=True)
    subprocess.run(["codex", "plugin", "add", PLUGIN], env=env, check=True)
    return True


def source_prompt(root: Path) -> str:
    prompt = root / "prompts" / "vibe-global-agent.md"
    if not prompt.is_file():
        raise RuntimeError("Global prompt is missing.")
    return prompt.read_text(encoding="utf-8").rstrip()


def read_state(home: Path) -> dict:
    state = home / "vibe-workflow" / STATE_NAME
    if not state.is_file():
        return {}
    try:
        data = json.loads(state.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


def install(root: Path, home: Path, *, without_mcp: bool) -> None:
    skills = source_skills(root)
    home.mkdir(parents=True, exist_ok=True)
    backup_dir = backup(home, "install", skills)

    agents = home / "AGENTS.md"
    old = agents.read_text(encoding="utf-8") if agents.exists() else ""
    block = f"{BEGIN}\n{source_prompt(root)}\n{END}"
    if managed_pattern().search(old):
        merged = managed_pattern().sub(block, old, count=1)
    else:
        merged = old.rstrip() + ("\n\n" if old.rstrip() else "") + block + "\n"
    agents.write_text(merged, encoding="utf-8", newline="\n")

    runtime_src = root / "runtime"
    runtime_dst = home / "vibe-workflow"
    if runtime_dst.exists():
        shutil.rmtree(runtime_dst)
    shutil.copytree(runtime_src, runtime_dst)

    installed_hashes: dict[str, str] = {}
    skills_dst = home / "skills"
    skills_dst.mkdir(parents=True, exist_ok=True)
    for skill in skills:
        dst = skills_dst / skill.name
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(skill, dst)
        installed_hashes[skill.name] = tree_hash(skill)

    plugin_installed = False
    if without_mcp:
        print("[*] MCP plugin skipped by --without-mcp.")
    else:
        plugin_installed = run_plugin(home, root)

    state = {
        "schema": 1,
        "installed_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "backup_dir": str(backup_dir),
        "skills": installed_hashes,
        "runtime_hash": tree_hash(runtime_dst),
        "mcp_plugin_installed": plugin_installed,
    }
    (runtime_dst / STATE_NAME).write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    verify(root, home, check_plugin=plugin_installed)
    print(f"[+] {TITLE} installed globally to: {home}")
    print(f"[+] Backup: {backup_dir}")


def verify(root: Path, home: Path, *, check_plugin: bool = False) -> None:
    agents = home / "AGENTS.md"
    if not agents.is_file():
        raise RuntimeError(f"Global AGENTS.md is missing: {agents}")
    match = managed_pattern().search(agents.read_text(encoding="utf-8"))
    if not match:
        raise RuntimeError("Vibe global managed block is missing.")
    inner = match.group(0)[len(BEGIN): -len(END)].strip()
    if norm(inner) != norm(source_prompt(root)):
        raise RuntimeError("Installed Vibe global prompt differs from this package.")
    for skill in source_skills(root):
        target = home / "skills" / skill.name / "SKILL.md"
        if not target.is_file():
            raise RuntimeError(f"Global skill is missing: {skill.name}")
        if tree_hash(skill) != tree_hash(target.parent):
            raise RuntimeError(f"Global skill differs from package: {skill.name}")
    runtime = home / "vibe-workflow"
    for name in ("scripts/init_project.py", "scripts/vibe.py", "scripts/render_subagent_prompt.py", "agents/roles.json", "agents/implementation-builder.md", "project-log-template/workflow.yaml"):
        if not (runtime / name).is_file():
            raise RuntimeError(f"Global runtime asset is missing: {name}")
    if check_plugin and shutil.which("codex") is not None:
        result = subprocess.run(["codex", "plugin", "list"], env=plugin_env(home), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if result.returncode or "vibe-toolbelt@vibe-global-toolbox" not in result.stdout or "installed, enabled" not in result.stdout:
            raise RuntimeError("Optional vibe-toolbelt plugin is not installed and enabled.")
    print("[+] Global installation verification passed.")


def restore_or_remove(current: Path, prior: Path, expected_hash: str, label: str) -> str:
    if not current.exists():
        return f"SKIP {label}: missing"
    if tree_hash(current) != expected_hash:
        return f"PRESERVE {label}: changed after installation"
    shutil.rmtree(current)
    if prior.exists():
        current.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(prior, current)
        return f"RESTORE {label}: pre-install copy"
    return f"REMOVE {label}"


def uninstall(root: Path, home: Path) -> None:
    skills = source_skills(root)
    state = read_state(home)
    backup_dir = backup(home, "uninstall", skills)
    agents = home / "AGENTS.md"
    if agents.exists():
        cleaned = managed_pattern().sub("", agents.read_text(encoding="utf-8"), count=1)
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
        if cleaned:
            agents.write_text(cleaned + "\n", encoding="utf-8", newline="\n")
        else:
            agents.unlink()

    previous = Path(state.get("backup_dir", "")) if state.get("backup_dir") else None
    for skill in skills:
        expected = str(state.get("skills", {}).get(skill.name, ""))
        current = home / "skills" / skill.name
        prior = previous / "skills" / skill.name if previous else Path("/nonexistent")
        if not expected:
            print(f"PRESERVE skills/{skill.name}: no installation state")
            continue
        print(restore_or_remove(current, prior, expected, f"skills/{skill.name}"))

    runtime = home / "vibe-workflow"
    runtime_hash = str(state.get("runtime_hash", ""))
    expected_runtime = tree_hash(root / "runtime")
    # installation-state is excluded from the digest, so compare against source runtime.
    prior_runtime = previous / "vibe-workflow" if previous else Path("/nonexistent")
    if runtime.exists() and runtime_hash and tree_hash(runtime) == expected_runtime:
        shutil.rmtree(runtime)
        if prior_runtime.exists():
            shutil.copytree(prior_runtime, runtime)
            print("RESTORE vibe-workflow: pre-install copy")
        else:
            print("REMOVE vibe-workflow")
    elif runtime.exists():
        print("PRESERVE vibe-workflow: changed after installation or no state")

    if state.get("mcp_plugin_installed"):
        run_plugin(home, root, remove=True)
    print(f"[+] Removed the Vibe-managed global layer. Backup: {backup_dir}")


def main() -> int:
    parser = argparse.ArgumentParser(description=TITLE)
    parser.add_argument("action", choices=("install", "verify", "uninstall"))
    parser.add_argument("--codex-home", help="Override CODEX_HOME for isolated tests or another user profile.")
    parser.add_argument("--without-mcp", action="store_true", help="Install persona, skills, and runtime but skip optional MCP plugin setup.")
    args = parser.parse_args()
    root = package_root()
    home = code_home(args.codex_home)
    try:
        if args.action == "install":
            install(root, home, without_mcp=args.without_mcp)
        elif args.action == "verify":
            verify(root, home, check_plugin=not args.without_mcp and bool(read_state(home).get("mcp_plugin_installed")))
        else:
            uninstall(root, home)
        return 0
    except Exception as exc:
        print(f"[X] {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
